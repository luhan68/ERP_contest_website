# checker.sh
python3 checker.py
